package com.udayLearning.ChatApp.ChatApp_May;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatAppMayApplicationTests {

	@Test
	void contextLoads() {
	}

}
